<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTokoShopndrive extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('toko_shopndrive', function (Blueprint $table) {
            $table->bigIncrements('no')->autoIncrement()->unsigned();
            $table->string('nama_toko', '100');
            $table->longText('alamat_toko');
            $table->string('post_code', '20');
            $table->string('wilayah_toko', '20');
            $table->string('store_toko', '10')->nullable();
            $table->string('kota_toko', '50');
            $table->string('cor_x', '50')->nullable();
            $table->string('cor_y', '50')->nullable();
            $table->string('dev_channel', '20');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('toko_shopndrive');
    }
}

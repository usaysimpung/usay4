<?php

namespace App\Http\Controllers;

use App\data_transaction;
use Illuminate\Support\Facades\DB;
use Ixudra\Curl\Facades\Curl;

class IrsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $idtrx = $_GET['idtrx'];
        $kodeproduk = $_GET['kode'];
        $tujuan = $_GET['tujuan'];


        $qry = DB::table('message_transaction')->where('Id_trx', $idtrx)->get()->toArray();
//        $url='http://grosirvoucher.com:1099/api/h2h?id=SA0001&user=FE56DD&pass=ABF649&pin=H8C30E&idtrx=' . $idtrx . '&kodeproduk=' . $kodeproduk . '&tujuan=' . $tujuan;
//        print $url;
        if (isset($qry[0]->Id_trx) == $idtrx) {
            return $qry[0]->res_trx;
        } else {

            $response = Curl::to('http://grosirvoucher.com:1099/api/h2h?id=SA0001&user=FE56DD&pass=ABF649&pin=H8C30E&idtrx=' . $idtrx . '&kodeproduk=' . $kodeproduk . '&tujuan=' . $tujuan)
                //$response = Curl::to('http://grosirvoucher.com:1202/reversalosh.php')
                ->get();
dd($response);

// dd($response);
//            print($response);

            DB::table('message_transaction')->insert(
                ['Id_trx' => $idtrx, 'no_tujuan' => $tujuan, 'res_trx'=>$response ]
            );

//            $res = new data_transaction();
//            $res->Id_trx = $idtrx;
//            $res->no_tujuan = $tujuan;
//            $res->res_trx = $response;
//            $res->save();
        }
    }
}

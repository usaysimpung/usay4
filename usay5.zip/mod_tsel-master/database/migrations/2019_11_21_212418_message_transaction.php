<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class MessageTransaction extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('message_transaction', function (Blueprint $table) {
            $table->bigIncrements('no')->autoIncrement()->unsigned();
            $table->string('Id_trx')->index();
            $table->string('no_tujuan', '20')->index();
            $table->string('res_trx')->index();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('message_transaction');
    }
}

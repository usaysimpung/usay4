<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Ixudra\Curl\Facades\Curl;
class ProductController extends Controller
{

    public function saldo()
    {

        $api_key = 'mdyatz6h9e9erj39xguhz76e';
        $secret = 'fRR4EwFVkD';
        $timestamp = gmdate('U');
        $sig = md5($api_key . $secret . $timestamp);
        $id_form=Carbon::now('Asia/Jakarta')->format('ymdHisu');
        $transaction_id='21128'.$id_form.mt_rand(00, 99);
        $response = Curl::to('https://dcore-dev.telkomsel.com/sit-web/scrt-ext/esb/v1/modern/offer/catalog/dealer?transaction_id='.$transaction_id.'&channel=i4&organization_code=211')
            ->withHeaders( array( 'Accept: application/json', 'Content-Type: application/json', 'api_key:'.$api_key, 'secret:'.$secret, 'x-signature:'.$sig ))
            ->asjsonresponse(true)
            ->get();




return $response;

    }

    public function stock()
    {

        $api_key = 'mdyatz6h9e9erj39xguhz76e';
        $secret = 'fRR4EwFVkD';
        $timestamp = gmdate('U');
        $sig = md5($api_key . $secret . $timestamp);
        $id_form=Carbon::now('Asia/Jakarta')->format('ymdHisu');
        $transaction_id='21128'.$id_form.mt_rand(00, 99);
        $response = Curl::to('https://dcore-dev.telkomsel.com/sit-web/scrt-ext/esb/v1/modern/offer/catalog/dealer?transaction_id='.$transaction_id.'&channel=i4&organization_code=211')
            ->withHeaders( array( 'Accept: application/json', 'Content-Type: application/json', 'api_key:'.$api_key, 'secret:'.$secret, 'x-signature:'.$sig ))
            ->asJsonResponse(true)
            ->get();


        return $response;

    }


}

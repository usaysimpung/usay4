<?php

namespace App\Http\Controllers;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Ixudra\Curl\Facades\Curl;
class RegulerRecharge extends Controller
{
    public function index()
    {


        $idtrx = $_GET['idtrx'];
        $kodeproduk = $_GET['kode'];
        $tujuan = $_GET['tujuan'];
        $amount = explode('.', $kodeproduk)[0];
        $type = explode('.', $kodeproduk)[1];
        $method_recharge = explode('.', $kodeproduk)[2];
        $id_form = Carbon::now('Asia/Jakarta')->format('ymdHisu');


        $api_key = 'mdyatz6h9e9erj39xguhz76e';
        $secret = 'fRR4EwFVkD';
        $timestamp = gmdate('U');
        $sig = md5($api_key . $secret . $timestamp);
        $transaction_id = '21128' . $id_form . mt_rand(00, 99);


        $json_saldo = array
        ('transaction' => array('transaction_id' => $transaction_id, 'channel' => 'i4'),
            'service' => array('organization_code' => '21128', 'service_id' => $tujuan),
            'recharge' => array('amount' => $amount, 'stock_type' => $type, 'element1' => 'R8rwKpGQf8i4XCQBd809Ig=='),
            'merchant_profile' => array('merchant_signature' => '00012341230192312', 'third_party_id' => 'kopnus_dev',
                'third_party_password' => 'kMhIAmNE4h8=', 'fund_source' => '', 'address' => '',
                'postcode' => '', 'district' => '', 'store_id' => '', 'city' => '', 'coordinate' => '', 'delivery_channel' => '',
                'transmission_date' => ''));

        $json_stock = array
        ('transaction' => array('transaction_id' => $transaction_id, 'channel' => 'i4'),
            'service' => array('organization_code' => '21128', 'service_id' => $tujuan),
            'order' => array('produk_id' => $amount, 'stock_type' => $type, 'element1' => 'R8rwKpGQf8i4XCQBd809Ig==','callback_url'=>''),
            'merchant_profile' => array('merchant_signature' => '00012341230192312', 'third_party_id' => 'POS_Broker',
                'third_party_password' => 'd3s1J5Rhh+UQFIlGc728gQ==', 'fund_source' => '', 'address' => '',
                'postcode' => '', 'district' => '', 'store_id' => '', 'city' => '', 'coordinate' => '', 'delivery_channel' => '',
                'transmission_date' => ''));


    if ($method_recharge === 'SALDO')

    {

        $qry = DB::table('message_transaction')->where('Id_trx', $idtrx)->get()->toArray();


        if (isset($qry[0]->Id_trx) == $idtrx)

        {
            return $qry[0]->res_trx;
        }
        else

            {


            $response = Curl::to('https://dcore-dev.telkomsel.com/sit-web/scrt-ext/esb/v1/modern/recharge/dealer')
                ->withHeaders(array('Accept: application/json', 'api_key:' . $api_key, 'secret:' . $secret, 'x-signature:' . $sig))
                ->withData($json_saldo)
                ->asJsonrequest(true)
                ->post();


            print($response);


            DB::table('message_transaction')->insert(
                ['Id_trx' => $idtrx, 'no_tujuan' => $tujuan, 'res_trx' => $response]
            );
////
//            $res = new data_transaction();
//            $res->Id_trx = $idtrx;
//            $res->no_tujuan = $tujuan;
//            $res->res_trx = $response;
//            $res->save();
        }

    }
    elseif ($method_recharge==='STOCK')

    {

        $qry = DB::table('message_transaction')->where('Id_trx', $idtrx)->get()->toArray();


        if (isset($qry[0]->Id_trx) == $idtrx)
        {
            return $qry[0]->res_trx;
        }

        else
            {

            $response = Curl::to('https://dcore-dev.telkomsel.com/sit-web/scrt-ext/esb/v1/modern/order/dealer')
                ->withHeaders(array('Accept: application/json', 'api_key:' . $api_key, 'secret:' . $secret, 'x-signature:' . $sig))
                ->withData($json_stock)
                ->asJsonrequest(true)
                ->post();


           print $response;


            DB::table('message_transaction')->insert(
                ['Id_trx' => $idtrx, 'no_tujuan' => $tujuan, 'res_trx' => $response]
            );
////
//            $res = new data_transaction();
//            $res->Id_trx = $idtrx;
//            $res->no_tujuan = $tujuan;
//            $res->res_trx = $response;
//            $res->save();
        }



    }
else

    {

    return "Method Recharge Tidak Dapat Diketahui";
}
    }

}

//}


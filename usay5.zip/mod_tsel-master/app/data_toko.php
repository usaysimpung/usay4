<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class data_toko extends Model
{
    //
    protected $table = "toko_shopndrive";

    protected $fillable = ['nama_toko','alamat_toko','post_code','wilayah_toko','store_toko','kota_toko','cor_x', 'cor_y', 'dev_channel'];

}

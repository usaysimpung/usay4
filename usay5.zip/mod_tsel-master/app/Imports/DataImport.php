<?php

namespace App\Imports;

use App\data_toko;
use Maatwebsite\Excel\Concerns\ToModel;

class DataImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new data_toko([
            'nama_toko' => $row[0],
            'alamat_toko' => $row[1],
            'post_code' => $row[2],
            'wilayah_toko' => $row[3],
            'store_toko' => $row[4],
            'kota_toko' => $row[5],
            'cor_x' => $row[6],
            'cor_y' => $row[7],
            'dev_channel' => $row[8],
        ]);
    }
}

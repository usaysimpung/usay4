<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/Product-Catalog/Saldo', 'ProductController@saldo');
Route::get('/Product-Catalog/Stock', 'ProductController@stock');
Route::get('/recharge', 'RegulerRecharge@index');
Route::get('/datatoko', 'DataTokoController@index');
Route::get('/datatoko/export_excel', 'DataTokoController@export_excel');
Route::post('/datatoko/import_excel', 'DataTokoController@import_excel');
Route::get('/rechargeirs', 'IrsController@index');

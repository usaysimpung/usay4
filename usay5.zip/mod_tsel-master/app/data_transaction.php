<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class data_transaction extends Model
{
    protected $table = "message_transaction";

    protected $fillable = ['Id_trx', 'no_tujuan', 'response'];
}
